#!/usr/bin/env bash

python tools/listkeys.py > tools/keys.txt
python tools/listkeys.py --controls > tools/controls.txt
